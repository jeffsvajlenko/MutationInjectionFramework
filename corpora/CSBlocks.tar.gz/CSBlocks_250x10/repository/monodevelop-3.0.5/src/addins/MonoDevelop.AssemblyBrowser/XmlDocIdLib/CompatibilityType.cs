using System;
using System.Collections.Generic;
using System.Text;

namespace XmlDocIdLib
{
#region CompatibilityType enumeration
public enum CompatibilityType
{
    None,
    Net11,
    Net35
}
#endregion
}
