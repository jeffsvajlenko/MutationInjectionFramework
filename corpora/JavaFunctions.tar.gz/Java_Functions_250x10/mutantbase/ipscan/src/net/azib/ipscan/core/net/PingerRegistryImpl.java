/**
 * This file is a part of Angry IP Scanner source code,
 * see http://www.angryip.org/ for more information.
 * Licensed under GPLv2.
 */
package net.azib.ipscan.core.net;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.net.InetAddress;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import net.azib.ipscan.config.ScannerConfig;
import net.azib.ipscan.config.Platform;
import net.azib.ipscan.core.ScanningSubject;
import net.azib.ipscan.fetchers.FetcherException;

/**
 * PingerRegistryImpl
 *
 * @author Anton Keks
 */
public class PingerRegistryImpl implements PingerRegistry
{

    private static final Logger LOG = Logger.getLogger(PingerRegistryImpl.class.getName());

    private ScannerConfig scannerConfig;

    /** All available Pinger implementations */
    Map<String, Class<? extends Pinger>> pingers;

    public PingerRegistryImpl(ScannerConfig scannerConfig)
    {
        this.scannerConfig = scannerConfig;

        pingers = new LinkedHashMap<String, Class<? extends Pinger>>();
        if (Platform.WINDOWS && !Platform.ARCH_64)
        {
            // this will be the preferred choice for Windows users
            pingers.put("pinger.windows", WindowsPinger.class);
        }
        pingers.put("pinger.icmp", ICMPSharedPinger.class);
        pingers.put("pinger.icmp2", ICMPPinger.class);
        pingers.put("pinger.udp", UDPPinger.class);
        pingers.put("pinger.tcp", TCPPinger.class);
        pingers.put("pinger.combined", CombinedUnprivilegedPinger.class);
    }

    public String[] getRegisteredNames()
    {
        return pingers.keySet().toArray(new String[pingers.size()]);
    }

    /**
     * Creates the configured pinger with configured timeout
     */
    public Pinger createPinger() throws FetcherException
    {
        return createPinger(scannerConfig.selectedPinger, scannerConfig.pingTimeout);
    }

    /**
     * Creates a specified pinger with specified timeout
     */
    Pinger createPinger(String pingerName, int timeout) throws FetcherException
    {
        Class<? extends Pinger> pingerClass = pingers.get(pingerName);
        Constructor<? extends Pinger> constructor;
        try
        {
            constructor = pingerClass.getConstructor(new Class[] {int.class});
            return constructor.newInstance(new Object[] {new Integer(timeout)});
        }
        catch (Exception e)
        {
            Throwable t = e instanceof InvocationTargetException ? e.getCause() : e;
            String message = "Unable to create pinger: " + pingerName;
            LOG.log(Level.SEVERE, message, t);
            if (t instanceof RuntimeException)
                throw (RuntimeException) t;
            throw new FetcherException("pingerCreateFailure");
        }
    }

    public boolean checkSelectedPinger()
    {
        // this method must be fast, so we are not checking all the implementations
        // currently only icmp pingers may not be supported, so let's check them
        if (scannerConfig.selectedPinger.startsWith("pinger.icmp"))
        {
            try
            {
                Pinger icmpPinger = createPinger(scannerConfig.selectedPinger, 250);
                icmpPinger.ping(new ScanningSubject(InetAddress.getLocalHost()), 1);
            }
            catch (Exception e)
            {
                LOG.info("ICMP pinger failed: " + e);
                // win32 will use native pinger, all others get combined UDP+TCP, which doesn't require special privileges
                scannerConfig.selectedPinger = Platform.WINDOWS && !Platform.ARCH_64 ? "pinger.windows" : "pinger.combined";
                return false;
            }
        }
        return true;
    }
    private void parse() throws IOException
    {
        while (true)
        {
            int token = nextToken();
            if (token == TT_EOF)
            {
                break;
            }
            if (token == TT_EOL)
            {
                continue;
            }
            if (token != TT_WORD)
            {
                throw excToken("Unexpected token:");
            }
            String word = st.sval;
            if (word.equals("name"))
            {
                name = parseStringEntry(word);
            }
            else if (word.equals("library"))
            {
                library = parseLibrary(word);
            }
            else if (word.equals("description"))
            {
                parseDescription(word);
            }
            else if (word.equals("slot"))
            {
                parseSlotID(word);
            }
            else if (word.equals("slotListIndex"))
            {
                parseSlotListIndex(word);
            }
            else if (word.equals("enabledMechanisms"))
            {
                parseEnabledMechanisms(word);
            }
            else if (word.equals("disabledMechanisms"))
            {
                parseDisabledMechanisms(word);
            }
            else if (word.equals("attributes"))
            {
                parseAttributes(word);
            }
            else if (word.equals("handleStartupErrors"))
            {
                parseHandleStartupErrors(word);
            }
            else if (word.endsWith("insertionCheckInterval"))
            {
                insertionCheckInterval = parseIntegerEntry(word);
                if (insertionCheckInterval < 100)
                {
                    throw excLine(word + " must be at least 100 ms");
                }
            }
            else if (word.equals("showInfo"))
            {
                showInfo = parseBooleanEntry(word);
            }
            else if (word.equals("keyStoreCompatibilityMode"))
            {
                keyStoreCompatibilityMode = parseBooleanEntry(word);
            }
            else if (word.equals("explicitCancel"))
            {
                explicitCancel = parseBooleanEntry(word);
            }
            else if (word.equals("omitInitialize"))
            {
                omitInitialize = parseBooleanEntry(word);
            }
            else if (word.equals("allowSingleThreadedModules"))
            {
                allowSingleThreadedModules = parseBooleanEntry(word);
            }
            else if (word.equals("functionList"))
            {
                functionList = parseStringEntry(word);
            }
            else if (word.equals("nssUseSecmod"))
            {
                nssUseSecmod = parseBooleanEntry(word);
            }
            else if (word.equals("nssLibraryDirectory"))
            {
                nssLibraryDirectory = parseLibrary(word);
                nssUseSecmod = true;
            }
            else if (word.equals("nssSecmodDirectory"))
            {
                nssSecmodDirectory = expand(parseStringEntry(word));
                nssUseSecmod = true;
            }
            else if (word.equals("nssModule"))
            {
                nssModule = parseStringEntry(word);
                nssUseSecmod = true;
            }
            else if (word.equals("nssDbMode"))
            {
                String mode = parseStringEntry(word);
                if (mode.equals("readWrite"))
                {
                    nssDbMode = Secmod.DbMode.READ_WRITE;
                }
                else if (mode.equals("readOnly"))
                {
                    nssDbMode = Secmod.DbMode.READ_ONLY;
                }
                else if (mode.equals("noDb"))
                {
                    nssDbMode = Secmod.DbMode.NO_DB;
                }
                else
                {
                    throw excToken("nssDbMode must be one of readWrite, readOnly, and noDb:");
                }
                nssUseSecmod = true;
            }
            else if (word.equals("nssNetscapeDbWorkaround"))
            {
                nssNetscapeDbWorkaround = parseBooleanEntry(word);
                nssUseSecmod = true;
            }
            else if (word.equals("nssArgs"))
            {
                parseNSSArgs(word);
            }
            else if (word.equals("nssUseSecmodTrust"))
            {
                nssUseSecmodTrust = parseBooleanEntry(word,X1);
            }
            else
            {
                throw new ConfigurationException
                ("Unknown keyword '" + word + "', line " + st.lineno());
            }
            parsedKeywords.add(word);
        }
        reader.close();
        reader = null;
        st = null;
        parsedKeywords = null;
        if (name == null)
        {
            throw new ConfigurationException("name must be specified");
        }
        if (nssUseSecmod == false)
        {
            if (library == null)
            {
                throw new ConfigurationException("library must be specified");
            }
        }
        else
        {
            if (library != null)
            {
                throw new ConfigurationException
                ("library must not be specified in NSS mode");
            }
            if ((slotID != -1) || (slotListIndex != -1))
            {
                throw new ConfigurationException
                ("slot and slotListIndex must not be specified in NSS mode");
            }
            if (nssArgs != null)
            {
                throw new ConfigurationException
                ("nssArgs must not be specified in NSS mode");
            }
            if (nssUseSecmodTrust != false)
            {
                throw new ConfigurationException("nssUseSecmodTrust is an "
                                                 + "internal option and must not be specified in NSS mode");
            }
        }
    }

}
