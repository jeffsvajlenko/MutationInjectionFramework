class MutantFragment {
	public void EmptyMethod() {
	}
    private void parse() throws IOException
    {
        while (true)
        {
            int token = nextToken();
            if (token == TT_EOF)
            {
                break;
            }
            if (token == TT_EOL)
            {
                continue;
            }
            if (token != TT_WORD)
            {
                throw excToken("Unexpected token:");
            }
            String word = st.sval;
            if (word.equals("name"))
            {
                name = parseStringEntry(word);
            }
            else if (word.equals("library"))
            {
                library = parseLibrary(word);
            }
            else if (word.equals("description"))
            {
                parseDescription(word);
            }
            else if (word.equals("slot"))
            {
                parseSlotID(word);
            }
            else if (word.equals("slotListIndex"))
            {
                parseSlotListIndex(word);
            }
            else if (word.equals("enabledMechanisms"))
            {
                parseEnabledMechanisms(word);
            }
            else if (word.equals("disabledMechanisms"))
            {
                parseDisabledMechanisms(word);
            }
            else if (word.equals("attributes"))
            {
                parseAttributes(word);
            }
            else if (word.equals("handleStartupErrors"))
            {
                parseHandleStartupErrors(word);
            }
            else if (word.endsWith("insertionCheckInterval"))
            {
                insertionCheckInterval = parseIntegerEntry(word);
                if (insertionCheckInterval < 100)
                {
                    throw excLine(word + " must be at least 100 ms");
                }
            }
            else if (word.equals("showInfo"))
            {
                showInfo = parseBooleanEntry(word);
            }
            else if (word.equals("keyStoreCompatibilityMode"))
            {
                keyStoreCompatibilityMode = parseBooleanEntry(word);
            }
            else if (word.equals("explicitCancel"))
            {
                explicitCancel = parseBooleanEntry(word);
            }
            else if (word.equals("omitInitialize"))
            {
                omitInitialize = parseBooleanEntry(word);
            }
            else if (word.equals("allowSingleThreadedModules"))
            {
                allowSingleThreadedModules = parseBooleanEntry(word);
            }
            else if (word.equals("functionList"))
            {
                functionList = parseStringEntry(word);
            }
            else if (word.equals("nssUseSecmod"))
            {
                nssUseSecmod = parseBooleanEntry(word);
            }
            else if (word.equals("nssLibraryDirectory"))
            {
                nssLibraryDirectory = parseLibrary(word);
                nssUseSecmod = true;
            }
            else if (word.equals("nssSecmodDirectory"))
            {
                nssSecmodDirectory = expand(parseStringEntry(word));
                nssUseSecmod = true;
            }
            else if (word.equals("nssModule"))
            {
                nssModule = parseStringEntry(word);
                nssUseSecmod = true;
            }
            else if (word.equals("nssDbMode"))
            {
                String mode = parseStringEntry(word);
                if (mode.equals("readWrite"))
                {
                    nssDbMode = Secmod.DbMode.READ_WRITE;
                }
                else if (mode.equals("readOnly"))
                {
                    nssDbMode = Secmod.DbMode.READ_ONLY;
                }
                else if (mode.equals("noDb"))
                {
                    nssDbMode = Secmod.DbMode.NO_DB;
                }
                else
                {
                    throw excToken("nssDbMode must be one of readWrite, readOnly, and noDb:");
                }
                nssUseSecmod = true;
            }
            else if (word.equals("nssNetscapeDbWorkaround"))
            {
                nssNetscapeDbWorkaround = parseBooleanEntry(word);
                nssUseSecmod = true;
            }
            else if (word.equals("nssArgs"))
            {
                parseNSSArgs(word);
            }
            else if (word.equals("nssUseSecmodTrust"))
            {
                nssUseSecmodTrust = parseBooleanEntry(word,X1);
            }
            else
            {
                throw new ConfigurationException
                ("Unknown keyword '" + word + "', line " + st.lineno());
            }
            parsedKeywords.add(word);
        }
        reader.close();
        reader = null;
        st = null;
        parsedKeywords = null;
        if (name == null)
        {
            throw new ConfigurationException("name must be specified");
        }
        if (nssUseSecmod == false)
        {
            if (library == null)
            {
                throw new ConfigurationException("library must be specified");
            }
        }
        else
        {
            if (library != null)
            {
                throw new ConfigurationException
                ("library must not be specified in NSS mode");
            }
            if ((slotID != -1) || (slotListIndex != -1))
            {
                throw new ConfigurationException
                ("slot and slotListIndex must not be specified in NSS mode");
            }
            if (nssArgs != null)
            {
                throw new ConfigurationException
                ("nssArgs must not be specified in NSS mode");
            }
            if (nssUseSecmodTrust != false)
            {
                throw new ConfigurationException("nssUseSecmodTrust is an "
                                                 + "internal option and must not be specified in NSS mode");
            }
        }
    }
}
