class MutantFragment {
	public void EmptyMethod() {
	}
}
