package sun.util.logging.resources;

import java.util.ListResourceBundle;

public final class logging_ja extends ListResourceBundle
{
    protected final Object[][] getContents()
    {
        return new Object[][]
        {
            { "ALL", "\u3059\u3079\u3066" },
            { "CONFIG", "\u8A2D\u5B9A" },
            { "FINE", "\u8A73\u7D30\u30EC\u30D9\u30EB (\u4F4E)" },
            { "FINER", "\u8A73\u7D30\u30EC\u30D9\u30EB (\u4E2D)" },
            { "FINEST", "\u8A73\u7D30\u30EC\u30D9\u30EB (\u9AD8)" },
            { "INFO", "\u60C5\u5831" },
            { "OFF", "\u30AA\u30D5" },
            { "SEVERE", "\u81F4\u547D\u7684" },
            { "WARNING", "\u8B66\u544A" },
        };
    }
}
