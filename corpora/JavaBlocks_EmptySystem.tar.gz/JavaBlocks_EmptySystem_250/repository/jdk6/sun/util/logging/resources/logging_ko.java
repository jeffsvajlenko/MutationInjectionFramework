package sun.util.logging.resources;

import java.util.ListResourceBundle;

public final class logging_ko extends ListResourceBundle
{
    protected final Object[][] getContents()
    {
        return new Object[][]
        {
            { "ALL", "\uBAA8\uB450" },
            { "CONFIG", "\uAD6C\uC131" },
            { "FINE", "\uC790\uC138\uD788" },
            { "FINER", "\uB354 \uC790\uC138\uD788" },
            { "FINEST", "\uC544\uC8FC \uC790\uC138\uD788" },
            { "INFO", "\uC815\uBCF4" },
            { "OFF", "\uC124\uC815\uD574\uC81C" },
            { "SEVERE", "\uC2EC\uAC01" },
            { "WARNING", "\uACBD\uACE0" },
        };
    }
}
