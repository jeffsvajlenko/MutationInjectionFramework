package sun.util.resources;

import java.util.ListResourceBundle;

public final class CurrencyNames_lt_LT extends LocaleNamesBundle
{
    protected final Object[][] getContents()
    {
        return new Object[][]
        {
            { "LTL", "Lt" },
        };
    }
}
