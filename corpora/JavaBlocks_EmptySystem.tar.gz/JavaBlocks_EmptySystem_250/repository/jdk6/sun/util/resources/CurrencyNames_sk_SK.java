package sun.util.resources;

import java.util.ListResourceBundle;

public final class CurrencyNames_sk_SK extends LocaleNamesBundle
{
    protected final Object[][] getContents()
    {
        return new Object[][]
        {
            { "SKK", "Sk" },
        };
    }
}
