package sun.util.resources;

import java.util.ListResourceBundle;

public final class CurrencyNames_in_ID extends LocaleNamesBundle
{
    protected final Object[][] getContents()
    {
        return new Object[][]
        {
            { "IDR", "Rp" },
        };
    }
}
