package sun.util.resources;

import java.util.ListResourceBundle;

public final class LocaleNames_sq extends LocaleNamesBundle
{
    protected final Object[][] getContents()
    {
        return new Object[][]
        {
            { "AL", "Shqip\u00EBria" },
            { "sq", "shqipe" },
        };
    }
}
