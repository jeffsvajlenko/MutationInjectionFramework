package sun.util.resources;

import java.util.ListResourceBundle;

public final class CurrencyNames_sr_BA extends LocaleNamesBundle
{
    protected final Object[][] getContents()
    {
        return new Object[][]
        {
            { "BAM", "\u041A\u041C." },
            { "EUR", "\u20AC" },
        };
    }
}
