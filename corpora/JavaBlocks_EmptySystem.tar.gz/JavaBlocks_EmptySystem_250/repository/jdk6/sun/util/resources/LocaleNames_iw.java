package sun.util.resources;

import java.util.ListResourceBundle;

public final class LocaleNames_iw extends LocaleNamesBundle
{
    protected final Object[][] getContents()
    {
        return new Object[][]
        {
            { "IL", "\u05D9\u05E9\u05E8\u05D0\u05DC" },
            { "iw", "\u05E2\u05D1\u05E8\u05D9\u05EA" },
        };
    }
}
