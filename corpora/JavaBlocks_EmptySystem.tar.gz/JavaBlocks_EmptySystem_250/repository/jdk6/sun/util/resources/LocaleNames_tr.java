package sun.util.resources;

import java.util.ListResourceBundle;

public final class LocaleNames_tr extends LocaleNamesBundle
{
    protected final Object[][] getContents()
    {
        return new Object[][]
        {
            { "TR", "T\u00FCrkiye" },
            { "tr", "T\u00FCrk\u00E7e" },
        };
    }
}
