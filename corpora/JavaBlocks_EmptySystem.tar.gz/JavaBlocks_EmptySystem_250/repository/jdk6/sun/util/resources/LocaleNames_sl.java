package sun.util.resources;

import java.util.ListResourceBundle;

public final class LocaleNames_sl extends LocaleNamesBundle
{
    protected final Object[][] getContents()
    {
        return new Object[][]
        {
            { "SI", "Slovenija" },
            { "sl", "Sloven\u0161\u010Dina" },
        };
    }
}
