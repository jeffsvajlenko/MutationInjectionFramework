package sun.util.resources;

import java.util.ListResourceBundle;

public final class LocaleNames_mk extends LocaleNamesBundle
{
    protected final Object[][] getContents()
    {
        return new Object[][]
        {
            { "MK", "\u041C\u0430\u043A\u0435\u0434\u043E\u043D\u0438\u0458\u0430" },
            { "mk", "\u043C\u0430\u043A\u0435\u0434\u043E\u043D\u0441\u043A\u0438" },
        };
    }
}
