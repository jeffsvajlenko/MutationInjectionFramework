package sun.util.resources;

import java.util.ListResourceBundle;

public final class LocaleNames_uk extends LocaleNamesBundle
{
    protected final Object[][] getContents()
    {
        return new Object[][]
        {
            { "UA", "\u0423\u043A\u0440\u0430\u0457\u043D\u0430" },
            { "uk", "\u0443\u043A\u0440\u0430\u0457\u043D\u0441\u044C\u043A\u0430" },
        };
    }
}
