package sun.util.resources;

import java.util.ListResourceBundle;

public final class CurrencyNames_sv_SE extends LocaleNamesBundle
{
    protected final Object[][] getContents()
    {
        return new Object[][]
        {
            { "EUR", "\u20AC" },
            { "SEK", "kr" },
        };
    }
}
