package sun.util.resources;

import java.util.ListResourceBundle;

public final class CurrencyNames_el_GR extends LocaleNamesBundle
{
    protected final Object[][] getContents()
    {
        return new Object[][]
        {
            { "EUR", "\u20AC" },
            { "GRD", "\u03B4\u03C1\u03C7" },
        };
    }
}
