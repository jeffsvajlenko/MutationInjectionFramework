package sun.util.resources;

import java.util.ListResourceBundle;

public final class CurrencyNames_uk_UA extends LocaleNamesBundle
{
    protected final Object[][] getContents()
    {
        return new Object[][]
        {
            { "UAH", "\u0433\u0440\u0432." },
        };
    }
}
