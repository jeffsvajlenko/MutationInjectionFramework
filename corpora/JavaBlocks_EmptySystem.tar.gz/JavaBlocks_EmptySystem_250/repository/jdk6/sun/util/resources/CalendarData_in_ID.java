package sun.util.resources;

import java.util.ListResourceBundle;

public final class CalendarData_in_ID extends LocaleNamesBundle
{
    protected final Object[][] getContents()
    {
        return new Object[][]
        {
            { "firstDayOfWeek", "2" },
        };
    }
}
