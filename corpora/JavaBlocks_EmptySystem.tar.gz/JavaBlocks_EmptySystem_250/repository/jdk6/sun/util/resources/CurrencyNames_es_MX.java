package sun.util.resources;

import java.util.ListResourceBundle;

public final class CurrencyNames_es_MX extends LocaleNamesBundle
{
    protected final Object[][] getContents()
    {
        return new Object[][]
        {
            { "MXN", "$" },
            { "USD", "US$" },
        };
    }
}
