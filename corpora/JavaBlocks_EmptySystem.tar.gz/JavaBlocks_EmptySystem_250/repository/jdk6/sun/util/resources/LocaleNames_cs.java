package sun.util.resources;

import java.util.ListResourceBundle;

public final class LocaleNames_cs extends LocaleNamesBundle
{
    protected final Object[][] getContents()
    {
        return new Object[][]
        {
            { "CZ", "\u010Cesk\u00E1 republika" },
            { "cs", "\u010De\u0161tina" },
        };
    }
}
