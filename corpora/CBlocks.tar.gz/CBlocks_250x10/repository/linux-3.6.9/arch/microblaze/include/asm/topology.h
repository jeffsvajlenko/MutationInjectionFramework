#include <asm-generic/topology.h>
