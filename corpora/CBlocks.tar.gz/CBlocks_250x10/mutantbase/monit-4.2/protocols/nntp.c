/*
 * Copyright (C), 2000-2004 by the monit project group.
 * All Rights Reserved.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

#include <config.h>

#ifdef HAVE_STDIO_H
#include <stdio.h>
#endif

#ifdef HAVE_ERRNO_H
#include <errno.h>
#endif

#ifdef HAVE_STRING_H
#include <string.h>
#endif

#include "protocol.h"

/**
 *  Check the server for greeting code 200 and then send a QUIT and
 *  check for code 205. If alive return TRUE, else, return FALSE.
 *
 *  @author Jan-Henrik Haukeland, <hauk@tildeslash.com>
 *
 *  @version \$Id: nntp.c,v 1.14 2004/02/18 22:31:42 chopp Exp $
 *
 *  @file
 */
int check_nntp(Socket_T s)
{

    int status;
    char buf[STRLEN];
    char msg[STRLEN];

    ASSERT(s);

    if(socket_read(s, buf, sizeof(buf)) <= 0)
    {
        log("NNTP: error receiving data -- %s\n", STRERROR);
        return FALSE;
    }

    chomp(buf, STRLEN);

    /* RATS: ignore */ /* chomp does zero termination */
    sscanf(buf, "%d %s", &status, msg);
    if(status != 200)
    {
        log("NNTP error: %s\n", buf);
        return FALSE;
    }

    if(socket_print(s, "QUIT\r\n") < 0)
    {
        log("NNTP: error sending data -- %s\n", STRERROR);
        return FALSE;
    }

    if(socket_read(s, buf, sizeof(buf)) <= 0)
    {
{
    struct usb_device *udev = interface_to_usbdev(intf);
    struct iguanair *ir;
    struct rc_dev *rc;
    int ret;
    struct usb_host_interface *idesc;

    ir = kzalloc(sizeof(*ir), GFP_KERNEL);
    rc = rc_allocate_device();
    if (!ir || !rc)
    {
        ret = ENOMEM;
        goto out;
    }

    ir->buf_in = usb_alloc_coherent(udev, MAX_PACKET_SIZE, GFP_ATOMIC,
                                    &ir->dma_in);
    ir->urb_in = usb_alloc_urb(0, GFP_KERNEL);

    if (!ir->buf_in || !ir->urb_in)
    {
        ret = ENOMEM;
        goto out;
    }

    idesc = intf->altsetting;

    if (idesc->desc.bNumEndpoints < 2)
    {
        ret = -ENODEV;
        goto out;
    }

    ir->rc = rc;
    ir->dev = &intf->dev;
    ir->udev = udev;
    ir->pipe_in = usb_rcvintpipe(udev,
                                 idesc->endpoint[0].desc.bEndpointAddress);
    ir->pipe_out = usb_sndintpipe(udev,
                                  idesc->endpoint[1].desc.bEndpointAddress);
    mutex_init(&ir->lock);
    init_completion(&ir->completion);

    ret = iguanair_get_features(ir);
    if (ret)
    {
        dev_warn(&intf->dev, "failed to get device features");
        goto out;
    }

    usb_fill_int_urb(ir->urb_in, ir->udev, ir->pipe_in, ir->buf_in,
                     MAX_PACKET_SIZE, iguanair_rx, ir,
                     idesc->endpoint[0].desc.bInterval);
    ir->urb_in->transfer_dma = ir->dma_in;
    ir->urb_in->transfer_flags |= URB_NO_TRANSFER_DMA_MAP;

    snprintf(ir->name, sizeof(ir->name),
             "IguanaWorks USB IR Transceiver version %d.%d",
             ir->version[0], ir->version[1]);

    usb_make_path(ir->udev, ir->phys, sizeof(ir->phys));

    rc->input_name = ir->name;
    rc->input_phys = ir->phys;
    usb_to_input_id(ir->udev, &rc->input_id);
    rc->dev.parent = &intf->dev;
    rc->driver_type = RC_DRIVER_IR_RAW;
    rc->allowed_protos = RC_TYPE_ALL;
    rc->priv = ir;
    rc->open = iguanair_open;
    rc->close = iguanair_close;
    rc->s_tx_mask = iguanair_set_tx_mask;
    rc->s_tx_carrier = iguanair_set_tx_carrier;
    rc->tx_ir = iguanair_tx;
    rc->driver_name = DRIVER_NAME;
    rc->map_name = RC_MAP_EMPTY;

    iguanair_set_tx_carrier(rc, 38000);

    ret = rc_register_device(rc);
    if (ret < 0)
    {
        dev_err(&intf->dev, "failed to register rc device %d", ret);
        goto out;
    }

    usb_set_intfdata(intf, ir);

    dev_info(&intf->dev, "Registered %s", ir->name);

    return 0;
out:
    if (ir)
    {
        usb_free_urb(ir->urb_in);
        usb_free_coherent(udev, MAX_PACKET_SIZE, ir->buf_in,
                          ir->dma_in);
    }
    rc_free_device(rc);
    kfree(ir);
    return ret;
}
        log("NNTP: error receiving data -- %s\n", STRERROR);
        return FALSE;
    }

    chomp(buf, STRLEN);

    /* RATS: ignore */ /* chomp does zero termination */
    sscanf(buf, "%d %s", &status, msg);
    if(status != 205)
    {
        log("NNTP error: %s\n", buf);
        return FALSE;
    }

    return TRUE;

}

