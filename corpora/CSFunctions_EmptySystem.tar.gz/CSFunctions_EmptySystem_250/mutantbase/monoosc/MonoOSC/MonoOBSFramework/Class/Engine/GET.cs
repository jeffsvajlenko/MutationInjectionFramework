// GET.cs created with MonoDevelop
//
//User: eric at 18:16 04/08/2008
//
// Copyright (C) 2008 [Petit Eric, surfzoid@gmail.com]
//
//Permission is hereby granted, free of charge, to any person
//obtaining a copy of this software and associated documentation
//files (the "Software"), to deal in the Software without
//restriction, including without limitation the rights to use,
//copy, modify, merge, publish, distribute, sublicense, and/or sell
//copies of the Software, and to permit persons to whom the
//Software is furnished to do so, subject to the following
//conditions:
//
//The above copyright notice and this permission notice shall be
//included in all copies or substantial portions of the Software.
//
//THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
//EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
//OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
//NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
//HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
//WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
//FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
//OTHER DEALINGS IN THE SOFTWARE.
//

using System;
using System.Collections.Generic;
using System.Text;
using System.Net;
using System.IO;
using System.Security.Cryptography.X509Certificates;

namespace MonoOBSFramework.Engine
{
/// <summary>
///
/// </summary>
public static class GET
{

    /// <summary>
    ///
    /// </summary>
    /// <param name="FuncAndArgs">
    /// A <see cref="System.String"/>
    /// </param>
    /// <param name="User">
    /// A <see cref="System.String"/>
    /// </param>
    /// <param name="Password">
    /// A <see cref="System.String"/>
    /// </param>
    /// <returns>
    /// A <see cref="StringBuilder"/>
    /// </returns>
    public static StringBuilder Getit(string FuncAndArgs, string User, string Password)
    {
        try
        {
            // Create the web request
            HttpWebRequest request
                = WebRequest.Create(VarGlobal.OpenSuseApiUrl + FuncAndArgs) as HttpWebRequest;
            if(!VarGlobal.LessVerbose)Console.WriteLine("GET {0}", request.Address.ToString());
            VarGlobal.NetEvManager.DoSomething(string.Format("GET {0}", request.Address.ToString()));

            //If proxy is not null, add it
            if(VarGlobal.Proxy != null) request.Proxy = VarGlobal.Proxy;

            // Add authentication to request
            request.Credentials = new NetworkCredential(User, Password);
            request.Timeout = VarGlobal.TimeOut;

            // Get response
            using (HttpWebResponse response = request.GetResponse() as HttpWebResponse)
            {
                // Get the response stream
                StreamReader reader = new StreamReader(response.GetResponseStream());

                // Console application output
                //if(!VarGlobal.LessVerbose)Console.WriteLine(reader.ReadToEnd());
                return new StringBuilder(reader.ReadToEnd());
            }
        }
        catch (Exception Ex)
        {

            VarGlobal.NetEvManager.DoSomething(Ex.Message);
            return new StringBuilder(Ex.Message + Environment.NewLine + Ex.StackTrace);
        }
    }
    public bool Define (DeclSpace parent, string method_full_name, Report Report)
    {
        TypeContainer container = parent.PartialContainer;

        PendingImplementation pending = container.PendingImplementations;
        if (pending != null)
        {
            implementing = pending.IsInterfaceMethod (method.MethodName, member.InterfaceType, this);

            if (member.InterfaceType != null)
            {
                if (implementing == null)
                {
                    if (member is PropertyBase)
                    {
                        Report.Error (550, method.Location, "`{0}' is an accessor not found in interface member `{1}{2}'",
                                      method.GetSignatureForError (), TypeManager.CSharpName (member.InterfaceType),
                                      member.GetSignatureForError ().Substring (member.GetSignatureForError ().LastIndexOf ('.')));

                    }
                    else
                    {
                        Report.Error (539, method.Location,
                                      "`{0}.{1}' in explicit interface declaration is not a member of interface",
                                      TypeManager.CSharpName (member.InterfaceType), member.ShortName);
                    }
                    return false;
                }
                if (implementing.IsAccessor && !(method is AbstractPropertyEventMethod))
                {
                    Report.SymbolRelatedToPreviousError (implementing);
                    Report.Error (683, method.Location, "`{0}' explicit method implementation cannot implement `{1}' because it is an accessor",
                                  member.GetSignatureForError (), TypeManager.CSharpSignature (implementing));
                    return false;
                }
            }
            else
            {
                if (implementing != null)
                {
                    AbstractPropertyEventMethod prop_method = method as AbstractPropertyEventMethod;
                    if (prop_method == null)
                    {
                        if (implementing.IsAccessor)
                        {
                            Report.SymbolRelatedToPreviousError (implementing);
                            Report.Error (470, method.Location, "Method `{0}' cannot implement interface accessor `{1}'",
                                          method.GetSignatureForError (), TypeManager.CSharpSignature (implementing));
                        }
                    }
                    else if (implementing.DeclaringType.IsInterface)
                    {
                        if (!implementing.IsAccessor)
                        {
                            Report.SymbolRelatedToPreviousError (implementing);
                            Report.Error (686, method.Location, "Accessor `{0}' cannot implement interface member `{1}' for type `{2}'. Use an explicit interface implementation",
                                          method.GetSignatureForError (), TypeManager.CSharpSignature (implementing), container.GetSignatureForError ());
                        }
                        else
                        {
                            PropertyBase.PropertyMethod pm = prop_method as PropertyBase.PropertyMethod;
                            if (pm != null && pm.HasCustomAccessModifier && (pm.ModFlags & Modifiers.PUBLIC) == 0)
                            {
                                Report.SymbolRelatedToPreviousError (implementing);
                                Report.Error (277, method.Location, "Accessor `{0}' must be declared public to implement interface member `{1}'",
                                              method.GetSignatureForError (), implementing.GetSignatureForError ());
                            }
                        }
                    }
                }
            }
        }

        //
        // For implicit implementations, make sure we are public, for
        // explicit implementations, make sure we are private.
        //
        if (implementing != null)
        {
            //
            // Setting null inside this block will trigger a more
            // verbose error reporting for missing interface implementations
            //
            // The "candidate" function has been flagged already
            // but it wont get cleared
            //
            if (member.IsExplicitImpl)
            {
                if (method.ParameterInfo.HasParams && !implementing.Parameters.HasParams)
                {
                    Report.SymbolRelatedToPreviousError (implementing);
                    Report.Error (466, method.Location, "`{0}': the explicit interface implementation cannot introduce the params modifier",
                                  method.GetSignatureForError ());
                }
            }
            else
            {
                if (implementing.DeclaringType.IsInterface)
                {
                    //
                    // If this is an interface method implementation,
                    // check for public accessibility
                    //
                    if ((flags & MethodAttributes.MemberAccessMask) != MethodAttributes.Public)
                    {
                        implementing = null;
                    }
                }
                else if ((flags & MethodAttributes.MemberAccessMask) == MethodAttributes.Private)
                {
                    // We may never be private.
                    implementing = null;

                }
                else if ((modifiers & Modifiers.OVERRIDE) == 0)
                {
                    //
                    // We may be protected if we're overriding something.
                    //
                    implementing = null;
                }
            }

            //
            // Static is not allowed
            //
            if ((modifiers & Modifiers.STATIC) != 0)
            {
                implementing = null;
            }
        }

        //
        // If implementing is still valid, set flags
        //
        if (implementing != null)
        {
            //
            // When implementing interface methods, set NewSlot
            // unless, we are overwriting a method.
            //
            if (implementing.DeclaringType.IsInterface)
            {
                if ((modifiers & Modifiers.OVERRIDE) == 0)
                    flags |= MethodAttributes.NewSlot;
            }

            flags |= MethodAttributes.Virtual | MethodAttributes.HideBySig;

            // Set Final unless we're virtual, abstract or already overriding a method.
            if ((modifiers & (Modifiers.VIRTUAL | Modifiers.ABSTRACT | Modifiers.OVERRIDE)) == 0)
                flags |= MethodAttributes.Final;

            //
            // clear the pending implementation flag (requires explicit methods to be defined first)
            //
            parent.PartialContainer.PendingImplementations.ImplementMethod (method.MethodName,
                    member.InterfaceType, this, member.IsExplicitImpl);

            //
            // Update indexer accessor name to match implementing abstract accessor
            //
            if (!implementing.DeclaringType.IsInterface && !member.IsExplicitImpl && implementing.IsAccessor)
                method_full_name = implementing.MemberDefinition.Name;
        }

        DefineMethodBuilder (container, method_full_name, method.ParameterInfo);

        if (builder == null)
            return false;

//			if (container.CurrentType != null)
//				declaring_type = container.CurrentType;
//			else
        declaring_type = container.Definition;

        if (implementing != null && member.IsExplicitImpl)
        {
            container.TypeBuilder.DefineMethodOverride (builder, (MethodInfo) implementing.GetMetaInfo ());
        }

        return true;
    }
}//Class
}//NameSpace
