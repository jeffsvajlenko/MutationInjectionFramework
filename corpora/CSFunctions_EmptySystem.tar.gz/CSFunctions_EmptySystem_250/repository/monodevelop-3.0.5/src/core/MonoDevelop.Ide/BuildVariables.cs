namespace MonoDevelop.Ide
{
internal class BuildVariables
{
    public static string PackageVersion = "3.0.5";
    public static string PackageVersionLabel = "3.0.5";
}
}

