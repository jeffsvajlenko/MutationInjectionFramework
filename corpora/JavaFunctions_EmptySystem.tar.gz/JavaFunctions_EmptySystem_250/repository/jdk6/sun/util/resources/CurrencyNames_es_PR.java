package sun.util.resources;

import java.util.ListResourceBundle;

public final class CurrencyNames_es_PR extends LocaleNamesBundle
{
    protected final Object[][] getContents()
    {
        return new Object[][]
        {
            { "USD", "$" },
        };
    }
}
