package sun.util.resources;

import java.util.ListResourceBundle;

public final class LocaleNames_is extends LocaleNamesBundle
{
    protected final Object[][] getContents()
    {
        return new Object[][]
        {
            { "IS", "\u00CDsland" },
            { "is", "\u00EDslenska" },
        };
    }
}
