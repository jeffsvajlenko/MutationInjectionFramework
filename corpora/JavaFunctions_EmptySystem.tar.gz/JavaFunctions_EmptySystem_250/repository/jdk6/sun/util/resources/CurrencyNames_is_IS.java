package sun.util.resources;

import java.util.ListResourceBundle;

public final class CurrencyNames_is_IS extends LocaleNamesBundle
{
    protected final Object[][] getContents()
    {
        return new Object[][]
        {
            { "ISK", "kr." },
        };
    }
}
