package sun.util.resources;

import java.util.ListResourceBundle;

public final class LocaleNames_lt extends LocaleNamesBundle
{
    protected final Object[][] getContents()
    {
        return new Object[][]
        {
            { "LT", "Lietuva" },
            { "lt", "Lietuvi\u0173" },
        };
    }
}
