package sun.util.resources;

import java.util.ListResourceBundle;

public final class LocaleNames_ar extends LocaleNamesBundle
{
    protected final Object[][] getContents()
    {
        return new Object[][]
        {
            { "AE", "\u0627\u0644\u0625\u0645\u0627\u0631\u0627\u062A" },
            { "BH", "\u0627\u0644\u0628\u062D\u0631\u064A\u0646" },
            { "DZ", "\u0627\u0644\u062C\u0632\u0627\u0626\u0631" },
            { "EG", "\u0645\u0635\u0631" },
            { "IQ", "\u0627\u0644\u0639\u0631\u0627\u0642" },
            { "JO", "\u0627\u0644\u0623\u0631\u062F\u0646" },
            { "KW", "\u0627\u0644\u0643\u0648\u064A\u062A" },
            { "LB", "\u0644\u0628\u0646\u0627\u0646" },
            { "LY", "\u0644\u064A\u0628\u064A\u0627" },
            { "MA", "\u0627\u0644\u0645\u063A\u0631\u0628" },
            { "OM", "\u0633\u0644\u0637\u0646\u0629 \u0639\u0645\u0627\u0646" },
            { "QA", "\u0642\u0637\u0631" },
            { "SA", "\u0627\u0644\u0633\u0639\u0648\u062F\u064A\u0629" },
            { "SD", "\u0627\u0644\u0633\u0648\u062F\u0627\u0646" },
            { "SY", "\u0633\u0648\u0631\u064A\u0627" },
            { "TN", "\u062A\u0648\u0646\u0633" },
            { "YE", "\u0627\u0644\u064A\u0645\u0646" },
            { "ar", "\u0627\u0644\u0639\u0631\u0628\u064A\u0629" },
        };
    }
}
