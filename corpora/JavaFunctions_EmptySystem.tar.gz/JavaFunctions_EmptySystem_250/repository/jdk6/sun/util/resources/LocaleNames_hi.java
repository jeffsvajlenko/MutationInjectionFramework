package sun.util.resources;

import java.util.ListResourceBundle;

public final class LocaleNames_hi extends LocaleNamesBundle
{
    protected final Object[][] getContents()
    {
        return new Object[][]
        {
            { "IN", "\u092D\u093E\u0930\u0924" },
            { "US", "\u0938\u0902\u092F\u0941\u0915\u094D\u0924 \u0930\u093E\u091C\u094D\u092F \u0905\u092E\u0947\u0930\u093F\u0915\u093E" },
            { "en", "\u0905\u0901\u0917\u094D\u0930\u0947\u091C\u093C\u0940" },
            { "hi", "\u0939\u093F\u0902\u0926\u0940" },
        };
    }
}
