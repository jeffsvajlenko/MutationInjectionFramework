package sun.util.resources;

import java.util.ListResourceBundle;

public final class CurrencyNames_be_BY extends LocaleNamesBundle
{
    protected final Object[][] getContents()
    {
        return new Object[][]
        {
            { "BYR", "\u0420\u0443\u0431" },
        };
    }
}
