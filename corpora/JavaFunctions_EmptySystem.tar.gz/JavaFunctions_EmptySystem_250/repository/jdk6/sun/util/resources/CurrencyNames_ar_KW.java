package sun.util.resources;

import java.util.ListResourceBundle;

public final class CurrencyNames_ar_KW extends LocaleNamesBundle
{
    protected final Object[][] getContents()
    {
        return new Object[][]
        {
            { "KWD", "\u062F.\u0643.\u200F" },
        };
    }
}
