package sun.util.resources;

import java.util.ListResourceBundle;

public final class CurrencyNames_ar_LY extends LocaleNamesBundle
{
    protected final Object[][] getContents()
    {
        return new Object[][]
        {
            { "LYD", "\u062F.\u0644.\u200F" },
        };
    }
}
