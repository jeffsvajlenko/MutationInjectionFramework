package sun.util.resources;

import java.util.ListResourceBundle;

public final class CalendarData_en_MT extends LocaleNamesBundle
{
    protected final Object[][] getContents()
    {
        return new Object[][]
        {
            { "minimalDaysInFirstWeek", "4" },
        };
    }
}
