package sun.util.resources;

import java.util.ListResourceBundle;

public final class CurrencyNames_ar_LB extends LocaleNamesBundle
{
    protected final Object[][] getContents()
    {
        return new Object[][]
        {
            { "LBP", "\u0644.\u0644.\u200F" },
        };
    }
}
