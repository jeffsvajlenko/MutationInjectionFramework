package sun.util.resources;

import java.util.ListResourceBundle;

public final class CurrencyNames_de_DE extends LocaleNamesBundle
{
    protected final Object[][] getContents()
    {
        return new Object[][]
        {
            { "DEM", "DM" },
            { "EUR", "\u20AC" },
        };
    }
}
