package sun.util.resources;

import java.util.ListResourceBundle;

public final class CurrencyNames_fr_BE extends LocaleNamesBundle
{
    protected final Object[][] getContents()
    {
        return new Object[][]
        {
            { "BEF", "FB" },
            { "EUR", "\u20AC" },
        };
    }
}
