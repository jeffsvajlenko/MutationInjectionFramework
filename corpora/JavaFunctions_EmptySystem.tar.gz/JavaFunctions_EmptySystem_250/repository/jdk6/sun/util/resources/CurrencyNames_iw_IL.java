package sun.util.resources;

import java.util.ListResourceBundle;

public final class CurrencyNames_iw_IL extends LocaleNamesBundle
{
    protected final Object[][] getContents()
    {
        return new Object[][]
        {
            { "ILS", "\u05E9\"\u05D7" },
        };
    }
}
