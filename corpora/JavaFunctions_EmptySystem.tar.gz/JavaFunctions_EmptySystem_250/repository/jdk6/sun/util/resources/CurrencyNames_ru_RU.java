package sun.util.resources;

import java.util.ListResourceBundle;

public final class CurrencyNames_ru_RU extends LocaleNamesBundle
{
    protected final Object[][] getContents()
    {
        return new Object[][]
        {
            { "RUB", "\u0440\u0443\u0431." },
        };
    }
}
