package sun.util.resources;

import java.util.ListResourceBundle;

public final class LocaleNames_da extends LocaleNamesBundle
{
    protected final Object[][] getContents()
    {
        return new Object[][]
        {
            { "DK", "Danmark" },
            { "da", "Dansk" },
        };
    }
}
