package sun.util.resources;

import java.util.ListResourceBundle;

public final class CurrencyNames_ms_MY extends LocaleNamesBundle
{
    protected final Object[][] getContents()
    {
        return new Object[][]
        {
            { "MYR", "RM" },
        };
    }
}
