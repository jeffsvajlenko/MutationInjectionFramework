#ifndef PERF_LINUX_MODULE_H
#define PERF_LINUX_MODULE_H

#define EXPORT_SYMBOL(name)

#endif
