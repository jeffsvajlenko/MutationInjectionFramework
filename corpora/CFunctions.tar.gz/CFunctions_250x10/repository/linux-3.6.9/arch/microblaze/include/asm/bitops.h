#include <asm-generic/bitops.h>
