class Fragment
{
	public void EmptyMethod()
	{
	}
}
