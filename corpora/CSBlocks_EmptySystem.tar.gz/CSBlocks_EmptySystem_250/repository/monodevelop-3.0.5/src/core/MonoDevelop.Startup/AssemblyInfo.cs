// <file>
//     <copyright see="prj:///doc/copyright.txt"/>
//     <license see="prj:///doc/license.txt"/>
//     <owner name="Mike Krger" email="mike@icsharpcode.net"/>
//     <version value="$version"/>
// </file>

using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("MonoDevelop")]
[assembly: AssemblyDescription("A full-featured IDE for Mono and Gtk#.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("MonoDevelop")]
[assembly: AssemblyCopyright("(c) 2004 MonoDevelop Team and Mike Krueger 2000-2003")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: AssemblyVersion("2.6.0.0")]
//[assembly: AssemblyDelaySign(false)]
//[assembly: AssemblyKeyFile("")]

