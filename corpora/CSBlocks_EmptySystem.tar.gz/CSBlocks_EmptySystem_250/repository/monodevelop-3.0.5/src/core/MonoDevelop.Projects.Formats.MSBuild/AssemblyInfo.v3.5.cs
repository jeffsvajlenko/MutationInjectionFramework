[assembly: System.Reflection.AssemblyTitle ("MonoDevelop MSBuild 3.5 Builder")]
