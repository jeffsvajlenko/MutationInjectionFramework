[assembly: System.Reflection.AssemblyTitle ("MonoDevelop MSBuild 4.0 Builder")]
