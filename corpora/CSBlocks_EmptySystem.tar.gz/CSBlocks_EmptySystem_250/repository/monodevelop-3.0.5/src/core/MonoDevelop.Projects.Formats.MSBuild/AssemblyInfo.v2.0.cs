[assembly: System.Reflection.AssemblyTitle ("MonoDevelop MSBuild 2.0 Builder")]
