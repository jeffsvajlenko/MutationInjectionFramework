/**
 * This file is a part of Angry IP Scanner source code,
 * see http://www.angryip.org/ for more information.
 * Licensed under GPLv2.
 */
package net.azib.ipscan.core.net;

import java.io.IOException;
import java.net.InetAddress;

import com.sun.jna.Native;
import com.sun.jna.win32.StdCallLibrary;
import net.azib.ipscan.core.ScanningSubject;

/**
 * Windows-only pinger that uses Microsoft's ICMP.DLL for its job.
 * <p/>
 * This pinger exists to provide adequate pinging to Windows users,
 * because Microsoft has removed Raw Socket support from consumer
 * versions of Windows since XP SP2.
 *
 * @author Anton Keks
 */
public class WindowsPinger implements Pinger
{
    private int timeout;
    private IcmpDll dll;

    public WindowsPinger(int timeout)
    {
        this.timeout = timeout;
        if (dll == null)
        {
            try
            {
                dll = (IcmpDll) Native.loadLibrary("iphlpapi", IcmpDll.class);
            }
            catch (UnsatisfiedLinkError e)
            {
                dll = (IcmpDll) Native.loadLibrary("icmp", IcmpDll.class);
            }
        }
    }

    public PingResult ping(ScanningSubject subject, int count) throws IOException
    {
        PingResult result = new PingResult(subject.getAddress());
        byte[] pingData = new byte[56];
        byte[] replyData = new byte[56 + 100];

        int handle = dll.IcmpCreateFile();
        if (handle < 0)
        {
            throw new IOException("Unable to create Windows native ICMP handle");
        }

        try
        {
            // send a bunch of packets
            for (int i = 1; i <= count && !Thread.currentThread().isInterrupted(); i++)
            {
                if (dll.IcmpSendEcho(handle, subject.getAddress().getAddress(), pingData, pingData.length, 0, replyData, replyData.length, timeout) > 0)
                {
                    int status = replyData[4] + (replyData[5]<<8) + (replyData[6]<<16) + (replyData[7]<<24);
                    if (status == 0)
                    {
    {

        if (!KeyUsage.isValid(usage))
        {
            throw new GeneralSecurityException("Invalid key usage number: "
                                               + usage);
        }

        byte[] Ke = null;
        byte[] Ki = null;

        try
        {
            // Derive encryption key

            byte[] constant = new byte[5];
            constant[0] = (byte) ((usage>>24)&0xff);
            constant[1] = (byte) ((usage>>16)&0xff);
            constant[2] = (byte) ((usage>>8)&0xff);
            constant[3] = (byte) (usage&0xff);

            constant[4] = (byte) 0xaa;

            Ke = dk(baseKey, constant);
            if (debug)
            {
                System.err.println("usage: " + usage);
                if (ivec != null)
                {
                    traceOutput("old_state.ivec", ivec, 0,X1, ivec.length);
                }
                traceOutput("plaintext", plaintext, start, Math.min(len, 32));
                traceOutput("constant", constant, 0, constant.length);
                traceOutput("baseKey", baseKey, 0, baseKey.length);
                traceOutput("Ke", Ke, 0, Ke.length);
            }

            // Encrypt
            // C1 = E(Ke, conf | plaintext | pad, oldivec)
            Cipher encCipher = getCipher(Ke, ivec, Cipher.ENCRYPT_MODE);
            int blockSize = encCipher.getBlockSize();
            byte[] confounder = Confounder.bytes(blockSize);

            int plainSize = roundup(confounder.length + len, blockSize);
            if (debug)
            {
                System.err.println("confounder = " + confounder.length +
                                   "; plaintext = " + len + "; padding = " +
                                   (plainSize - confounder.length - len) + "; total = " +
                                   plainSize);
                traceOutput("confounder", confounder, 0, confounder.length);
            }

            byte[] toBeEncrypted = new byte[plainSize];
            System.arraycopy(confounder, 0, toBeEncrypted,
                             0, confounder.length);
            System.arraycopy(plaintext, start, toBeEncrypted,
                             confounder.length, len);

            // Set padding bytes to zero
            Arrays.fill(toBeEncrypted, confounder.length + len, plainSize,
                        (byte)0);

            int cipherSize = encCipher.getOutputSize(plainSize);
            int ccSize =  cipherSize + getChecksumLength();  // cipher | hmac

            byte[] ciphertext = new byte[ccSize];

            encCipher.doFinal(toBeEncrypted, 0, plainSize, ciphertext, 0);

            // Update ivec for next operation
            // (last blockSize bytes of ciphertext)
            // newstate.ivec = newIV
            if (new_ivec != null && new_ivec.length == blockSize)
            {
                System.arraycopy(ciphertext,  cipherSize - blockSize,
                                 new_ivec, 0, blockSize);
                if (debug)
                {
                    traceOutput("new_ivec", new_ivec, 0, new_ivec.length);
                }
            }

            // Derive integrity key
            constant[4] = (byte) 0x55;
            Ki = dk(baseKey, constant);
            if (debug)
            {
                traceOutput("constant", constant, 0, constant.length);
                traceOutput("Ki", Ki, 0, Ke.length);
            }

            // Generate checksum
            // H1 = HMAC(Ki, conf | plaintext | pad)
            byte[] hmac = getHmac(Ki, toBeEncrypted);

            if (debug)
            {
                traceOutput("hmac", hmac, 0, hmac.length);
                traceOutput("ciphertext", ciphertext, 0,
                            Math.min(ciphertext.length, 32));
            }

            // C1 | H1[1..h]
            System.arraycopy(hmac, 0, ciphertext, cipherSize,
                             getChecksumLength());
            return ciphertext;
        }
        finally
        {
            if (Ke != null)
            {
                Arrays.fill(Ke, 0, Ke.length, (byte) 0);
            }
            if (Ki != null)
            {
                Arrays.fill(Ki, 0, Ki.length, (byte) 0);
            }
        }
    }
                        int roundTripTime = replyData[8] + (replyData[9]<<8) + (replyData[10]<<16) + (replyData[11]<<24);
                        int timeToLive = replyData[20] & 0xFF;
                        result.addReply(roundTripTime);
                        result.setTTL(timeToLive);
                    }
                }
            }
        }
        finally
        {
            dll.IcmpCloseHandle(handle);
        }

        return result;
    }

    public void close() throws IOException
    {
        // not needed in this pinger
    }

    public interface IcmpDll extends StdCallLibrary
    {
        /**
         * Wrapper for Microsoft's  {@linkplain http://msdn.microsoft.com/en-US/library/aa366045.aspx IcmpCreateFile}
         */
        int IcmpCreateFile();

        /**
         * Wrapper for Microsoft's {@linkplain http://msdn.microsoft.com/EN-US/library/aa366050.aspx IcmpSendEcho}
         */
        int IcmpSendEcho(int handle, byte[] address, byte[] pingData, int pingDataSize, int options, byte[] replyData, int replyDataSize, int timeout);

        /**
         * Wrapper for Microsoft's IcmpCreateFile: {@linkplain http://msdn.microsoft.com/en-us/library/aa366043.aspx IcmpCloseHandle}
         */
        void IcmpCloseHandle(int handle);
    }

    public static void main(String[] args) throws IOException
    {
        PingResult ping = new WindowsPinger(2000).ping(new ScanningSubject(InetAddress.getLocalHost()), 1);
        System.out.println(ping.getAverageTime());
    }
}
